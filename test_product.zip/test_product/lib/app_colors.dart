import 'package:flutter/material.dart';

class AppColors {
  static const blue = Color.fromARGB(255, 11, 172, 221);
  static const bgmain = Color(0xe4e4e4e4);
}
