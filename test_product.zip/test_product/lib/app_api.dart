class AppUrl {
  static const url = "http://10.0.2.2:8080/PHP%20Projects/BBU%20Project/test/";
}
